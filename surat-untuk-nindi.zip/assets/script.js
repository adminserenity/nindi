
const messages = [
  "Nindi, kamu tuh kayak kopi… makin malam makin bikin deg-degan, tapi bikin nagih juga 😚",
  "Kalau disuruh milih antara kamu dan tidur… aku pilih kamu. Soalnya, mimpi indah cuma ada kalau ada kamu 😴💘",
  "Nindi, aku tuh bukan anak bahasa… tapi tiap lihat kamu, rasanya pengen ngungkapin cinta pakai 1000 majas 😍",
  "Cintaku ke kamu tuh kayak kuota unlimited… nggak ada abisnya, walau sinyal hati kamu kadang lemot 😅❤️",
  "Kalau kamu nanya kenapa aku sayang kamu… ya karena kamu bukan lelucon, tapi kamu bikin aku ketawa tiap hari 😆💕"
];

function startApp() {
  setTimeout(() => {
    document.getElementById('loading').style.display = 'none';
    document.getElementById('main-content').classList.remove('hidden');
    applyTimeTheme();
  }, 2000);
}

function openEnvelope() {
  document.getElementById('envelope').classList.add('hidden');
  const letter = document.getElementById('letter');
  letter.classList.remove('hidden');
  const random = Math.floor(Math.random() * messages.length);
  document.getElementById('message-text').innerText = messages[random];
}

function applyTimeTheme() {
  const hour = new Date().getHours();
  if (hour >= 5 && hour < 11) {
    document.body.style.background = "#fceabb";
  } else if (hour >= 11 && hour < 16) {
    document.body.style.background = "#a0e3f0";
  } else if (hour >= 16 && hour < 19) {
    document.body.style.background = "#ffccbc";
  } else {
    document.body.style.background = "#2c3e50";
    document.body.style.color = "#fff";
  }
}
