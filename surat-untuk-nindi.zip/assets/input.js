
const messages = [
  "Nindi, kamu tuh kayak kopi… makin malam makin bikin deg-degan, tapi bikin nagih juga 😚",
  "Kalau disuruh milih antara kamu dan tidur… aku pilih kamu. Soalnya, mimpi indah cuma ada kalau ada kamu 😴💘",
  "Nindi, aku tuh bukan anak bahasa… tapi tiap lihat kamu, rasanya pengen ngungkapin cinta pakai 1000 majas 😍",
  "Cintaku ke kamu tuh kayak kuota unlimited… nggak ada abisnya, walau sinyal hati kamu kadang lemot 😅❤️",
  "Kalau kamu nanya kenapa aku sayang kamu… ya karena kamu bukan lelucon, tapi kamu bikin aku ketawa tiap hari 😆💕"
];

function renderMessages() {
  const ul = document.getElementById("messageList");
  ul.innerHTML = "";
  messages.forEach(msg => {
    const li = document.createElement("li");
    li.innerText = msg;
    ul.appendChild(li);
  });
}

function addMessage() {
  const textarea = document.getElementById("newMessage");
  const text = textarea.value.trim();
  if (text) {
    messages.push(text);
    renderMessages();
    textarea.value = "";
  }
}

renderMessages();
